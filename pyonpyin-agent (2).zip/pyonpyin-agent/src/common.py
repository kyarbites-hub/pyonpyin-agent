"""PyonPyin - script အားလုံးက မျှသုံးတဲ့ အခြေခံ function များ။

ဒီဖိုင်ကို ပြင်စရာ မလိုပါ။ Key/Secret တွေကို ဒီဖိုင်ထဲ မရေးပါနဲ့ -
GitHub Settings > Secrets ထဲမှာပဲ ထည့်ပါ။
"""

import datetime as dt
import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

BASE_DIR = Path(__file__).resolve().parent.parent
STATE_FILE = BASE_DIR / "data" / "run_state.json"

# ---- Secret/env မရှိရင် ဒီတန်ဖိုးတွေကို သုံးမယ် ----
# (Secret ကို "ဗလာ" ထားမိရင်လည်း `or` ကြောင့် default ကို ပြန်သုံးပါမယ်)
SPREADSHEET_ID = os.environ.get("SPREADSHEET_ID") or "1qTC6NH6HM4sIo6XT-C4fffaVK1eQ44MGL6fARQ07uI4"
GEMINI_MODEL = os.environ.get("GEMINI_MODEL") or "gemini-3.8-flash"
GEMINI_FALLBACKS = ["gemini-3.6-flash", "gemini-3.5-flash"]

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]
SOURCE_TAB = "SourceQueue"
STORY_TAB = "Stories"
USER_AGENT = "PyonPyinAgent/1.0 (story research bot)"

# SourceQueue ရဲ့ column ၃၁ ခု (သင့် Sheet နဲ့ တူတူပါ)
SOURCE_HEADERS = [
    "story_id", "original_title", "author", "source_id", "source_name", "source_url",
    "source_language", "category", "source_text", "source_published_at", "discovered_at",
    "duplicate_status", "source_license_rule", "category_evidence", "license_name",
    "license_url", "license_evidence", "license_status", "rights_cleared",
    "rights_jurisdiction", "permission_for_translation", "permission_for_ai_processing",
    "permission_for_publication", "permission_for_audio", "permission_for_commercial_use",
    "source_text_segment_count", "human_reviewer", "review_status", "discovery_error",
    "rights_mode", "broad_theme",
]

# Stories tab (Agent က အလိုအလျောက် ဆောက်ပေးမယ်)
STORY_HEADERS = [
    "story_id", "source_story_id", "segment_index", "book_title", "original_title",
    "author", "source_name", "source_url", "title_my", "story_my", "quiz_json",
    "reflection_my", "status", "reviewer", "review_notes", "model", "created_at",
    "published_at",
]


# ------------------------------------------------------------------ အသေးစား tools
def utc_now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def sha_id(text, prefix="pp-"):
    return prefix + hashlib.sha256(text.encode("utf-8")).hexdigest()[:24]


def slugify(text):
    return re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")


def norm_url(url):
    return (url or "").strip().rstrip("/")


def short_error(error):
    """Secret မပါအောင် error ကို တိုတိုပဲ ပြမယ်။"""
    return f"{type(error).__name__}: {str(error)[:200]}"


def http_get_bytes(url, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return response.read()


def http_get(url, timeout=30):
    return http_get_bytes(url, timeout).decode("utf-8", errors="replace")


# ------------------------------------------------------------------ run state (dashboard အတွက်)
def save_state(key, info):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    try:
        state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        state = {}
    info["time"] = utc_now()
    state[key] = info
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def load_state():
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


# ------------------------------------------------------------------ Google Sheets
def connect():
    token_json = os.environ.get("GOOGLE_TOKEN_JSON")
    if not token_json:
        raise RuntimeError(
            "GOOGLE_TOKEN_JSON Secret မတွေ့ပါ။ GitHub > Settings > Secrets and variables > Actions ကို စစ်ပါ။"
        )
    creds = Credentials.from_authorized_user_info(json.loads(token_json), scopes=SCOPES)
    return build("sheets", "v4", credentials=creds, cache_discovery=False)


def col_letter(index):
    """0 -> A, 25 -> Z, 26 -> AA"""
    letters = ""
    index += 1
    while index:
        index, rem = divmod(index - 1, 26)
        letters = chr(65 + rem) + letters
    return letters


def ensure_tab(service, tab, headers):
    """Tab မရှိရင် ဆောက်မယ်၊ header မပြည့်ရင် ဖြည့်မယ်။ နောက်ဆုံး header စာရင်းကို ပြန်ပေးမယ်။"""
    meta = service.spreadsheets().get(
        spreadsheetId=SPREADSHEET_ID, fields="sheets.properties.title"
    ).execute()
    titles = [s["properties"]["title"] for s in meta.get("sheets", [])]
    if tab not in titles:
        service.spreadsheets().batchUpdate(
            spreadsheetId=SPREADSHEET_ID,
            body={"requests": [{"addSheet": {"properties": {"title": tab}}}]},
        ).execute()
        print(f"Created tab: {tab}")

    result = service.spreadsheets().values().get(
        spreadsheetId=SPREADSHEET_ID, range=f"{tab}!1:1"
    ).execute()
    current = (result.get("values") or [[]])[0]
    missing = [h for h in headers if h not in current]
    if missing:
        current = current + missing
        service.spreadsheets().values().update(
            spreadsheetId=SPREADSHEET_ID, range=f"{tab}!A1",
            valueInputOption="RAW", body={"values": [current]},
        ).execute()
        print(f"{tab}: added header columns: {missing}")
    return current


def read_rows(service, tab):
    """Header အမည်နဲ့ဖတ်မယ် (column နံပါတ်မမှတ်ရအောင်)။ (headers, rows) ပြန်ပေးမယ်။"""
    values = service.spreadsheets().values().get(
        spreadsheetId=SPREADSHEET_ID, range=f"{tab}!A1:AZ"
    ).execute().get("values", [])
    if not values:
        return [], []
    headers = values[0]
    rows = []
    for number, raw in enumerate(values[1:], start=2):
        raw = list(raw) + [""] * (len(headers) - len(raw))
        row = {h: str(c).strip() for h, c in zip(headers, raw)}
        row["_row"] = number
        if any(v for k, v in row.items() if k != "_row"):
            rows.append(row)
    return headers, rows


def append_rows(service, tab, headers, dict_rows):
    if not dict_rows:
        return
    values = [[str(d.get(h, "")) for h in headers] for d in dict_rows]
    service.spreadsheets().values().append(
        spreadsheetId=SPREADSHEET_ID, range=f"{tab}!A1",
        valueInputOption="RAW", insertDataOption="INSERT_ROWS",
        body={"values": values},
    ).execute()


def update_cells(service, tab, headers, updates):
    """updates = [(row_number, field_name, value), ...]  တစ်ခါတည်း ရေးမယ်။"""
    data = []
    for row_number, field, value in updates:
        if field not in headers:
            continue
        data.append({
            "range": f"{tab}!{col_letter(headers.index(field))}{row_number}",
            "values": [[value]],
        })
    if data:
        service.spreadsheets().values().batchUpdate(
            spreadsheetId=SPREADSHEET_ID,
            body={"valueInputOption": "RAW", "data": data},
        ).execute()


def is_cleared(row):
    """လူကိုယ်တိုင် လိုင်စင်စစ်ပြီး အားလုံးပြည့်စုံမှသာ True။ (AI က ဒါကို မပြောင်းပါ)"""
    yes = lambda f: row.get(f, "").strip().upper() == "YES"
    return bool(
        row.get("source_url")
        and row.get("license_status", "").strip().upper() == "APPROVED"
        and yes("rights_cleared")
        and row.get("license_evidence")
        and row.get("human_reviewer")
        and row.get("rights_jurisdiction")
        and yes("permission_for_translation")
        and yes("permission_for_ai_processing")
        and yes("permission_for_publication")
    )


# ------------------------------------------------------------------ Gemini
def parse_json_text(text):
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("Gemini က JSON မပြန်ပါ")
    return json.loads(text[start:end + 1])


def gemini_json(prompt, retries=3):
    """Gemini ကို ခေါ်ပြီး JSON ပြန်ယူမယ်။ (result, model_name) ပြန်ပေးမယ်။"""
    key = os.environ.get("GEMINI_API_KEY")
    if not key:
        raise RuntimeError("GEMINI_API_KEY Secret မတွေ့ပါ။")

    models = [GEMINI_MODEL] + [m for m in GEMINI_FALLBACKS if m != GEMINI_MODEL]
    body = json.dumps({
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"responseMimeType": "application/json", "temperature": 0.7},
    }).encode("utf-8")
    last = "unknown error"

    for model in models:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        for attempt in range(1, retries + 1):
            req = urllib.request.Request(
                url, data=body,
                headers={"x-goog-api-key": key, "Content-Type": "application/json"},
            )
            try:
                with urllib.request.urlopen(req, timeout=180) as response:
                    data = json.load(response)
            except urllib.error.HTTPError as error:
                detail = error.read().decode("utf-8", "replace")[:200]
                last = f"{model}: HTTP {error.code} {detail}"
                if error.code == 404:       # model အမည်မရှိ -> နောက် model စမ်း
                    break
                if error.code in (429, 500, 502, 503, 504):
                    time.sleep(10 * attempt)
                    continue
                raise RuntimeError(last)
            except urllib.error.URLError as error:
                last = f"{model}: {error.reason}"
                time.sleep(5)
                continue

            parts = (data.get("candidates") or [{}])[0].get("content", {}).get("parts", [])
            text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
            if not text.strip():
                last = f"{model}: empty response (blocked?)"
                break
            return parse_json_text(text), model
    raise RuntimeError(last)
