"""အဆင့် ၂ - လူက လိုင်စင်အတည်ပြုပြီးသား စာအုပ်တွေကိုပဲ မြန်မာလို ပြန်ရေးမယ်။

ထွက်လာတာကို Stories tab ထဲ status = DRAFT_AI နဲ့ ထည့်မယ်။
လူက ဖတ်ပြီး status ကို PUBLISHED လို့ ပြောင်းမှ website ပေါ် တက်မယ်။
"""

import os
import re
import time

from bs4 import BeautifulSoup

from common import (
    BASE_DIR, SOURCE_HEADERS, SOURCE_TAB, STORY_HEADERS, STORY_TAB, append_rows,
    connect, ensure_tab, gemini_json, http_get, is_cleared, read_rows,
    save_state, short_error, update_cells, utc_now,
)
import json

MAX_STORIES_PER_RUN = int(os.environ.get("MAX_STORIES_PER_RUN") or 3)
MAX_FAILURES_PER_RUN = 3
MIN_WORDS, MAX_WORDS = 150, 6000       # ဒီအပိုင်းအခြားထဲက အပိုင်းတွေကိုပဲ ပြန်ရေးမယ်
PROMPT_FILE = BASE_DIR / "prompts" / "story_writer.txt"

# စာအုပ်ရဲ့ ရှေ့/နောက်ပိုင်း (ခေါင်းစဉ်စာမျက်နှာ၊ မိတ်ဆက်၊ မှတ်စု) ကို ကျော်မယ်
SKIP_TYPES = {
    "titlepage", "halftitlepage", "imprint", "colophon", "copyright-page", "uncopyright",
    "toc", "endnotes", "footnotes", "dedication", "epigraph", "foreword", "preface",
    "introduction", "afterword", "glossary", "bibliography", "index", "loi", "frontmatter",
    "backmatter", "acknowledgments", "contributors", "appendix",
}


def fetch_segments(book_url):
    """စာအုပ်တစ်အုပ်လုံးကို single-page နဲ့ယူပြီး အခန်း/ပုံပြင်တစ်ပုဒ်စီ ခွဲမယ်။"""
    html = http_get(book_url.rstrip("/") + "/text/single-page", timeout=60)
    soup = BeautifulSoup(html, "html.parser")
    segments = []
    for section in soup.find_all(["section", "article"]):
        if section.find(["section", "article"]):
            continue                                  # အတွင်းဆုံး အပိုင်းကိုပဲ ယူမယ်
        types = set()
        for node in [section] + list(section.parents):
            types |= set(str(node.get("epub:type", "")).split())
        if types & SKIP_TYPES:
            continue
        paragraphs = [p.get_text(" ", strip=True) for p in section.find_all("p")]
        text = "\n\n".join(p for p in paragraphs if p)
        words = len(text.split())
        if not (MIN_WORDS <= words <= MAX_WORDS):
            continue
        heading = section.find(re.compile(r"^h[1-6]$"))
        if heading is None and section.parent is not None:
            heading = section.parent.find(re.compile(r"^h[1-6]$"))
        title = heading.get_text(" ", strip=True) if heading else f"Part {len(segments) + 1}"
        segments.append({"title": title, "text": text, "words": words})
    return segments


def validate_story(result):
    """AI ရဲ့ ရလဒ် ပြည့်စုံမှန်ကန်မှု စစ်မယ်။ မှားရင် ValueError။"""
    if not isinstance(result, dict):
        raise ValueError("result is not an object")
    for key in ("title", "story", "reflection"):
        if not isinstance(result.get(key), str) or not result[key].strip():
            raise ValueError(f"missing {key}")
    quiz = result.get("quiz")
    if not isinstance(quiz, list) or len(quiz) != 3:
        raise ValueError("quiz must have exactly 3 items")
    for item in quiz:
        if not (isinstance(item, dict) and str(item.get("question", "")).strip()
                and str(item.get("answer", "")).strip()):
            raise ValueError("quiz item incomplete")
    story = result["story"]
    myanmar = len(re.findall(r"[\u1000-\u109F]", story))
    if len(story) < 200 or myanmar < len(story) * 0.4:
        raise ValueError("story too short or not Myanmar text")


def write_story(book, segment):
    template = PROMPT_FILE.read_text(encoding="utf-8")
    prompt = (template
              .replace("{{BOOK_TITLE}}", book.get("original_title", ""))
              .replace("{{AUTHOR}}", book.get("author", ""))
              .replace("{{SEGMENT_TITLE}}", segment["title"])
              .replace("{{SOURCE_TEXT}}", segment["text"]))
    last_error = None
    for attempt in range(2):                         # JSON/ပုံစံမှားရင် ၂ ကြိမ်ထိ ပြန်စမ်း
        try:
            result, model = gemini_json(prompt)
            validate_story(result)
            return result, model
        except ValueError as error:
            last_error = error
            time.sleep(3)
    raise ValueError(f"invalid AI output: {last_error}")


def main():
    service = connect()
    src_headers = ensure_tab(service, SOURCE_TAB, SOURCE_HEADERS)
    story_headers = ensure_tab(service, STORY_TAB, STORY_HEADERS)
    _, books = read_rows(service, SOURCE_TAB)
    _, stories = read_rows(service, STORY_TAB)
    done = {(s.get("source_story_id", ""), s.get("segment_index", "")) for s in stories}

    cleared = [b for b in books if is_cleared(b)]
    print(f"Cleared books: {len(cleared)} / {len(books)}")
    if not cleared:
        print("လိုင်စင်အတည်ပြုပြီးသား စာအုပ် မရှိသေးပါ။ Sheet မှာ လူကိုယ်တိုင် အတည်ပြုပါ။")

    made, failures, errors = 0, 0, []
    for book in cleared:
        if made >= MAX_STORIES_PER_RUN or failures >= MAX_FAILURES_PER_RUN:
            break
        print(f"\nBook: {book['original_title']}")
        try:
            segments = fetch_segments(book["source_url"])
        except Exception as error:
            msg = f"fetch text: {short_error(error)}"
            errors.append(msg)
            failures += 1
            update_cells(service, SOURCE_TAB, src_headers, [(book["_row"], "discovery_error", msg)])
            continue
        print(f"  usable segments: {len(segments)}")
        updates = [(book["_row"], "source_text_segment_count", str(len(segments)))]

        for index, segment in enumerate(segments, start=1):
            if made >= MAX_STORIES_PER_RUN or failures >= MAX_FAILURES_PER_RUN:
                break
            if (book["story_id"], str(index)) in done:
                continue
            print(f"  writing #{index}: {segment['title']} ({segment['words']} words)")
            try:
                result, model = write_story(book, segment)
            except Exception as error:
                msg = f"segment {index}: {short_error(error)}"
                errors.append(msg)
                failures += 1
                updates.append((book["_row"], "discovery_error", msg))
                continue
            append_rows(service, STORY_TAB, story_headers, [{
                "story_id": f"{book['story_id']}-s{index:03d}",
                "source_story_id": book["story_id"],
                "segment_index": str(index),
                "book_title": book["original_title"],
                "original_title": segment["title"],
                "author": book["author"],
                "source_name": book["source_name"],
                "source_url": book["source_url"],
                "title_my": result["title"].strip(),
                "story_my": result["story"].strip(),
                "quiz_json": json.dumps(result["quiz"], ensure_ascii=False),
                "reflection_my": result["reflection"].strip(),
                "status": "DRAFT_AI",
                "model": model,
                "created_at": utc_now(),
            }])
            done.add((book["story_id"], str(index)))
            made += 1
            if book.get("discovery_error"):
                updates.append((book["_row"], "discovery_error", ""))
            time.sleep(2)
        update_cells(service, SOURCE_TAB, src_headers, updates)

    print(f"\nDraft stories written: {made}, failures: {failures}")
    save_state("writer", {"drafts_written": made, "failures": failures, "errors": errors[:5]})
    print("Draft တွေကို Stories tab မှာ ဖတ်ပြီး PUBLISHED ပြောင်းမှ website ပေါ်တက်မယ်။")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"Story Writer failed: {short_error(error)}")
        raise
