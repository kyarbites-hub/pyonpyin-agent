"""အဆင့် ၁ - Standard Ebooks မှ ပုံပြင်နဲ့ဆင်တဲ့ စာအုပ်တွေ ရှာပြီး SourceQueue ထဲ ထည့်မယ်။

- Feed (စာအုပ်အသစ်) + Subject စာမျက်နှာ (Children's, Shorts) + seed_books.json က URL တွေကို ရှာတယ်
- ပုံပြင်နဲ့ မဆိုင်တာ (စစ်ပွဲမှတ်တမ်း၊ ဒဿနိက စသည်) ကို Sheet ထဲ မထည့်ဘူး
- လိုင်စင်အတည်ပြုချက်တွေကို AI က ဘယ်တော့မှ မဖြည့်ဘူး (လူကပဲ ဖြည့်မယ်)
"""

import json
import re
import time
import xml.etree.ElementTree as ET
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

from common import (
    BASE_DIR, SOURCE_HEADERS, SOURCE_TAB, append_rows, connect, ensure_tab,
    http_get, http_get_bytes, norm_url, read_rows, save_state, sha_id,
    short_error, slugify, update_cells, utc_now,
)

SE = "https://standardebooks.org"
NS = {"atom": "http://www.w3.org/2005/Atom"}
SOURCES_FILE = BASE_DIR / "data" / "approved_sources.json"
SEEDS_FILE = BASE_DIR / "data" / "seed_books.json"
MAX_NEW_PER_RUN = 15          # တစ်ကြိမ် run မှာ စာအုပ်အသစ် ဘယ်နှစ်အုပ်ထိ ထည့်မလဲ
SUBJECT_PAGES = 2             # subject တစ်ခုချင်းစီက စာမျက်နှာ ဘယ်နှစ်မျက်နှာ ဖတ်မလဲ


def classify(text):
    """Subject စာသားကနေ ပုံပြင်အမျိုးအစား ခန့်မှန်းမယ်။ မဟုတ်ရင် NOT_A_STORY။"""
    t = (text or "").lower()
    rules = [
        ("FABLE", ["fable"]),
        ("FAIRY_TALE", ["fairy tale", "fairy-tale", "fairies"]),
        ("FOLK_TALE", ["folklore", "folk tale", "legends", "mythology", "myths"]),
        ("CHILDREN_STORY", ["children", "juvenile"]),
        ("SHORT_STORY", ["short stories", "short fiction", "shorts"]),
    ]
    for category, keywords in rules:
        if any(k in t for k in keywords):
            return category
    return "NOT_A_STORY"


def load_sources():
    sources = json.loads(SOURCES_FILE.read_text(encoding="utf-8"))
    return [s for s in sources
            if s.get("approval_status") == "APPROVED" and s.get("automation_allowed") is True]


def load_seeds():
    try:
        urls = json.loads(SEEDS_FILE.read_text(encoding="utf-8")).get("urls", [])
    except Exception:
        return []
    # Standard Ebooks URL ကိုပဲ လက်ခံမယ် (တခြား site တွေက မအတည်ပြုရသေးလို့)
    return [u.strip() for u in urls if u.strip().startswith(SE + "/ebooks/")]


# ------------------------------------------------------------------ ရှာတဲ့ နည်းလမ်း ၃ ခု
def from_feed(feed_url):
    root = ET.fromstring(http_get_bytes(feed_url))
    found = []
    for entry in root.findall("atom:entry", NS):
        url = ""
        for link in entry.findall("atom:link", NS):
            if link.get("rel") in (None, "alternate") and link.get("href"):
                url = urljoin(SE, link.get("href"))
                break
        if not url:
            url = (entry.findtext("atom:id", "", NS) or "").strip()
        if "/ebooks/" not in url or "/downloads/" in url:
            continue
        subjects = [c.get("term", "") for c in entry.findall("atom:category", NS)]
        found.append({
            "url": url,
            "title": (entry.findtext("atom:title", "", NS) or "").strip(),
            "author": (entry.findtext("atom:author/atom:name", "", NS) or "").strip(),
            "subjects": "; ".join(s for s in subjects if s),
        })
    return found


def links_from_subject(subject_url):
    links = []
    for page in range(1, SUBJECT_PAGES + 1):
        url = subject_url if page == 1 else f"{subject_url}?page={page}"
        try:
            soup = BeautifulSoup(http_get(url), "html.parser")
        except Exception as error:
            print(f"  subject page skipped ({short_error(error)})")
            break
        added = 0
        for a in soup.select("a[href]"):
            path = urlparse(urljoin(SE, a["href"])).path
            parts = [p for p in path.split("/") if p]
            if (len(parts) >= 3 and parts[0] == "ebooks"
                    and not set(parts) & {"text", "downloads", "single-page"}):
                full = SE + "/" + "/".join(parts)
                if full not in links:
                    links.append(full)
                    added += 1
        if not added:
            break
        time.sleep(1)
    return links


def book_meta(url):
    """စာအုပ်စာမျက်နှာကနေ အမည်၊ စာရေးသူ၊ subject တွေ ယူမယ်။"""
    soup = BeautifulSoup(http_get(url), "html.parser")
    h1 = soup.find("h1")
    title = h1.get_text(" ", strip=True) if h1 else url.rstrip("/").split("/")[-1]
    author = ""
    if h1:
        a = h1.find_next("a", href=re.compile(r"^(https://standardebooks\.org)?/ebooks/[^/]+/?$"))
        if a:
            author = a.get_text(strip=True)
    subjects = []
    for a in soup.select('a[href*="/subjects/"]'):
        text = a.get_text(" ", strip=True)
        if text and text not in subjects:
            subjects.append(text)
    return {"url": url, "title": title, "author": author, "subjects": "; ".join(subjects)}


# ------------------------------------------------------------------ Sheet ထဲ ထည့်ခြင်း
def new_row(book, source_name, license_rule):
    return {
        "story_id": sha_id(norm_url(book["url"])),
        "original_title": book["title"],
        "author": book["author"],
        "source_id": slugify(source_name),
        "source_name": source_name,
        "source_url": book["url"],
        "source_language": "en",
        "category": classify(book["subjects"]),
        "discovered_at": utc_now(),
        "duplicate_status": "UNIQUE",
        "source_license_rule": license_rule,
        "category_evidence": book["subjects"],
        "license_status": "NEEDS_LICENSE_REVIEW",
        "rights_cleared": "NO",
        "permission_for_translation": "NO",
        "permission_for_ai_processing": "NO",
        "permission_for_publication": "NO",
        "permission_for_audio": "NO",
        "permission_for_commercial_use": "NO",
        "review_status": "PENDING_REVIEW",
        "rights_mode": "UNKNOWN",
    }


def backfill(service, headers, rows):
    """ရှိပြီးသား row တွေရဲ့ အလွတ်နေရာတွေကို လုံခြုံတဲ့ default နဲ့ ဖြည့်မယ်။
    လူရေးထားတာကို ဘယ်တော့မှ မထိဘူး (အလွတ်ဖြစ်မှသာ ဖြည့်မယ်)။"""
    updates = []
    defaults = {
        "source_language": "en", "duplicate_status": "UNIQUE",
        "license_status": "NEEDS_LICENSE_REVIEW", "rights_cleared": "NO",
        "permission_for_translation": "NO", "permission_for_ai_processing": "NO",
        "permission_for_publication": "NO", "permission_for_audio": "NO",
        "permission_for_commercial_use": "NO", "review_status": "PENDING_REVIEW",
        "rights_mode": "UNKNOWN",
    }
    for r in rows:
        if not r.get("source_url"):
            continue
        n = r["_row"]
        if not r.get("story_id"):
            updates.append((n, "story_id", sha_id(norm_url(r["source_url"]))))
        for field, value in defaults.items():
            if not r.get(field):
                updates.append((n, field, value))
        if r.get("source_id", "").startswith("http") or not r.get("source_id"):
            updates.append((n, "source_id", slugify(r.get("source_name")) or "standard-ebooks"))

        evidence = r.get("category_evidence", "").replace("Unmapped feed category:", "").strip()
        if r.get("category", "") in ("", "UNCLASSIFIED") and evidence:
            category = classify(evidence)
            updates.append((n, "category", category))
            if category == "NOT_A_STORY" and r.get("review_status", "PENDING_REVIEW") in ("", "PENDING_REVIEW"):
                updates.append((n, "review_status", "SKIPPED_NOT_STORY"))
    update_cells(service, SOURCE_TAB, headers, updates)
    print(f"Backfilled cells: {len(updates)}")


def main():
    errors = []
    print("Connecting to Google Sheets...")
    service = connect()
    headers = ensure_tab(service, SOURCE_TAB, SOURCE_HEADERS)
    _, rows = read_rows(service, SOURCE_TAB)
    existing = {norm_url(r["source_url"]) for r in rows if r.get("source_url")}
    print(f"Rows already in sheet: {len(existing)}")

    backfill(service, headers, rows)

    candidates = []   # (book dict, source_name, license_rule)
    for source in load_sources():
        name, rule = source["source_name"], source.get("license_rule", "Verify each work")
        print(f"\nChecking source: {name}")

        if source.get("feed_url"):
            try:
                items = from_feed(source["feed_url"])
                print(f"  feed entries: {len(items)}")
                candidates += [(b, name, rule) for b in items]
            except Exception as error:
                errors.append(f"feed: {short_error(error)}")
                print(f"  feed failed: {short_error(error)}")

        urls = []
        for subject_url in source.get("subject_urls", []):
            print(f"  subject: {subject_url}")
            urls += links_from_subject(subject_url)
        if source_name_is_standard(name):
            urls += load_seeds()
        fresh = [u for u in dict.fromkeys(urls) if norm_url(u) not in existing]
        for url in fresh[:MAX_NEW_PER_RUN]:
            try:
                candidates.append((book_meta(url), name, rule))
                time.sleep(1)
            except Exception as error:
                errors.append(f"book page: {short_error(error)}")

    new_rows, skipped_non_story, seen = [], 0, set(existing)
    for book, name, rule in candidates:
        key = norm_url(book["url"])
        if not key or key in seen:
            continue
        seen.add(key)
        row = new_row(book, name, rule)
        if row["category"] == "NOT_A_STORY":
            skipped_non_story += 1          # ပုံပြင်မဟုတ်ရင် Sheet ထဲ မထည့်ဘူး
            continue
        new_rows.append(row)
        if len(new_rows) >= MAX_NEW_PER_RUN:
            break

    append_rows(service, SOURCE_TAB, headers, new_rows)
    print(f"\nNew story-like books added: {len(new_rows)}")
    print(f"Skipped (not a story): {skipped_non_story}")
    for r in new_rows:
        print(f"  + {r['original_title']} [{r['category']}]")

    save_state("finder", {"added": len(new_rows), "skipped_non_story": skipped_non_story,
                          "errors": errors[:5]})
    print("\nDone. လိုင်စင်စစ်ဆေးခြင်းကို လူကိုယ်တိုင် လုပ်ရမယ်။ Auto publish ပိတ်ထားတယ်။")


def source_name_is_standard(name):
    return "standard ebooks" in name.lower()


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"Story Finder failed: {short_error(error)}")
        raise
