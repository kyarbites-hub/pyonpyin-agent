"""အဆင့် ၃ - PUBLISHED ဖြစ်တဲ့ ဇာတ်လမ်းတွေကို website အတွက် JSON ထုတ်မယ်။

site/data/stories.json  -> ဇာတ်လမ်းစာရင်း (PUBLISHED ပဲ)
site/data/status.json   -> Dashboard အတွက် အရေအတွက်များ (ခေါင်းစဉ်/လျှို့ဝှက်ချက် မပါ)
"""

import json
from collections import Counter

from common import (
    BASE_DIR, SOURCE_HEADERS, SOURCE_TAB, STORY_HEADERS, STORY_TAB, connect,
    ensure_tab, is_cleared, load_state, read_rows, save_state, short_error,
    update_cells, utc_now,
)

OUT_DIR = BASE_DIR / "site" / "data"


def parse_quiz(text):
    try:
        quiz = json.loads(text)
        return [{"question": str(q["question"]), "answer": str(q["answer"])} for q in quiz]
    except Exception:
        return []


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    service = connect()
    src_headers = ensure_tab(service, SOURCE_TAB, SOURCE_HEADERS)
    story_headers = ensure_tab(service, STORY_TAB, STORY_HEADERS)
    _, books = read_rows(service, SOURCE_TAB)
    _, stories = read_rows(service, STORY_TAB)
    books_by_id = {b["story_id"]: b for b in books if b.get("story_id")}

    published, blocked, updates = [], 0, []
    for s in stories:
        if s.get("status", "").upper() != "PUBLISHED":
            continue
        if not s.get("title_my") or not s.get("story_my"):
            continue
        book = books_by_id.get(s.get("source_story_id", ""))
        # လုံခြုံရေး: မူရင်းစာအုပ်ရဲ့ လိုင်စင်အတည်ပြုချက် ပြည့်စုံမှသာ ထုတ်ပြန်မယ်
        if not book or not is_cleared(book):
            blocked += 1
            continue
        published_at = s.get("published_at") or utc_now()
        if not s.get("published_at"):
            updates.append((s["_row"], "published_at", published_at))
        published.append({
            "id": s["story_id"],
            "title": s["title_my"],
            "story": s["story_my"],
            "quiz": parse_quiz(s.get("quiz_json", "")),
            "reflection": s.get("reflection_my", ""),
            "book_title": s.get("book_title", ""),
            "section": s.get("original_title", ""),
            "author": s.get("author", ""),
            "source_name": s.get("source_name", ""),
            "source_url": s.get("source_url", ""),
            "published_at": published_at,
        })
    update_cells(service, STORY_TAB, story_headers, updates)
    published.sort(key=lambda x: x["published_at"], reverse=True)

    (OUT_DIR / "stories.json").write_text(
        json.dumps({"updated_at": utc_now(), "stories": published}, ensure_ascii=False, indent=1),
        encoding="utf-8")

    state = load_state()
    status = {
        "updated_at": utc_now(),
        "published_count": len(published),
        "blocked_by_license": blocked,
        "queue_total": len(books),
        "queue_cleared": sum(1 for b in books if is_cleared(b)),
        "queue_by_review_status": dict(Counter(b.get("review_status") or "-" for b in books)),
        "queue_by_category": dict(Counter(b.get("category") or "-" for b in books)),
        "stories_by_status": dict(Counter(s.get("status") or "-" for s in stories)),
        "runs": {k: state.get(k, {}) for k in ("finder", "writer")},
    }
    (OUT_DIR / "status.json").write_text(
        json.dumps(status, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"Published stories exported: {len(published)} (blocked by license check: {blocked})")
    save_state("exporter", {"published": len(published), "blocked": blocked})


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"Export failed: {short_error(error)}")
        raise
