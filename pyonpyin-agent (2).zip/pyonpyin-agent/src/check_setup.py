"""Setup စစ်ဆေးသူ - Key/Sheet/Gemini/Standard Ebooks အားလုံး အလုပ်လုပ်လား စစ်မယ်။
GitHub > Actions > "Check setup" ကနေ run ပါ။ Secret တန်ဖိုးတွေကို ဘယ်တော့မှ မပြပါ။
"""

import os
import sys

from common import (
    SOURCE_HEADERS, SOURCE_TAB, SPREADSHEET_ID, STORY_HEADERS, STORY_TAB, connect,
    ensure_tab, gemini_json, http_get, read_rows, short_error,
)

failed = False


def step(name, func):
    global failed
    try:
        detail = func()
        print(f"[OK]   {name}" + (f" - {detail}" if detail else ""))
    except Exception as error:
        failed = True
        print(f"[FAIL] {name} - {short_error(error)}")


def check_secrets():
    names = ["GOOGLE_TOKEN_JSON", "GEMINI_API_KEY"]
    missing = [n for n in names if not os.environ.get(n)]
    if missing:
        raise RuntimeError("Secret မတွေ့ပါ: " + ", ".join(missing))
    return "Secret ၂ ခု ရှိတယ်"


def check_sheet():
    service = connect()
    ensure_tab(service, SOURCE_TAB, SOURCE_HEADERS)
    ensure_tab(service, STORY_TAB, STORY_HEADERS)
    _, books = read_rows(service, SOURCE_TAB)
    _, stories = read_rows(service, STORY_TAB)
    return f"Sheet ...{SPREADSHEET_ID[-6:]} ချိတ်မိတယ်၊ SourceQueue {len(books)} row, Stories {len(stories)} row"


def check_gemini():
    result, model = gemini_json('Reply with only this JSON: {"ok": true}')
    if result.get("ok") is not True:
        raise RuntimeError("unexpected reply")
    return f"model = {model}"


def check_standard_ebooks():
    html = http_get("https://standardebooks.org/subjects/childrens")
    if "/ebooks/" not in html:
        raise RuntimeError("book links not found")
    return "Standard Ebooks ဖတ်လို့ရတယ်"


step("Secrets", check_secrets)
step("Google Sheet", check_sheet)
step("Gemini", check_gemini)
step("Standard Ebooks", check_standard_ebooks)

print("\n" + ("အားလုံး အဆင်ပြေပါတယ်။" if not failed else "[FAIL] ပါတာတွေကို ပြင်ပါ။"))
sys.exit(1 if failed else 0)
