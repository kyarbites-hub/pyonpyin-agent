# PyonPyin Agent

Public-domain ပုံပြင်များကို မြန်မာလို ပြန်ရေးပြီး website ပေါ်တင်တဲ့ စနစ်။

```
Standard Ebooks ──► SourceQueue (Sheet) ──► [လူ: လိုင်စင်စစ်] ──► Gemini ဇာတ်လမ်းရေး
 ──► Stories (Sheet, DRAFT_AI) ──► [လူ: မြန်မာစာဖတ်စစ်၊ PUBLISHED ပြောင်း] ──► Website + Dashboard
```

**လူက အတည်ပြုမှ ရှေ့ဆက်တယ်** - AI က လိုင်စင်ကော၊ ထုတ်ပြန်တာကော ကိုယ်တိုင် မဆုံးဖြတ်ပါ။

---

## တစ်ခါတည်း လုပ်ရမယ့် Setup (၁၀ မိနစ်ခန့်)

### ၁. GitHub repo ထဲ ဖိုင်အသစ်တွေ တင်ပါ
1. ဒီ zip ကို unzip လုပ်ပါ။
2. GitHub repo (`pyonpyin-agent`) ကိုဖွင့် → **Add file → Upload files** → unzip လုပ်ထားတဲ့ folder **ထဲက ဖိုင်/folder အားလုံး** ကို ဆွဲထည့်ပါ → **Commit changes**။
   - `.github` folder က Mac/Linux မှာ ဖျောက်ထားတတ်ပါတယ် (Mac: `Cmd + Shift + .` နှိပ်ရင် ပေါ်တယ်)။
3. **အဟောင်း workflow ၂ ဖိုင်ကို ဖျက်ပါ**: `.github/workflows/gemini-test.yml` နဲ့ `.github/workflows/story-finder.yml` (ဖိုင်ဖွင့် → ညာဘက်ထောင့် `···` → **Delete file** → Commit)။

### ၂. Secrets စစ်ပါ (အသစ်မလိုပါ၊ ရှိပြီးသားပါ)
GitHub repo → **Settings → Secrets and variables → Actions** မှာ ဒီအမည် ၂ ခု ရှိရမယ် (စာလုံးအကြီးအသေးပါ တိတိကျကျ):

| Secret | ဘာလဲ |
|---|---|
| `GOOGLE_TOKEN_JSON` | Google Sheets OAuth token (အရင်ကတည်းက ထည့်ပြီးသား) |
| `GEMINI_API_KEY` | Gemini API key (အရင် test workflow မှာ သုံးခဲ့တာ) |

(ရွေးချယ်စရာ) `SPREADSHEET_ID` Secret ထည့်ရင် code ထဲက default Sheet ID အစား ဒါကို သုံးမယ်။ မထည့်လည်း ရတယ်။

### ၃. Workflow permission ဖွင့်ပါ
**Settings → Actions → General → Workflow permissions** → **Read and write permissions** ရွေး → **Save**။

### ၄. Website hosting ဖွင့်ပါ (GitHub Pages)
**Settings → Pages → Build and deployment → Source: GitHub Actions** ရွေးပါ။

> GitHub Free မှာ **private repo** က Pages မရပါဘူး။ Repo ကို **public** လုပ်ပါ (Settings → General → Danger Zone → Change visibility)။
> Public လုပ်ရင်တောင် Secrets တွေ မမြင်ရပါ။ ဒါပေမယ့် repo ထဲမှာ ဘာမှ လျှို့ဝှက်ချက် မရှိရပါဘူး (ဒီ project ထဲမှာ မရှိပါ)။

### ၅. Setup စစ်ပါ
**Actions → Check setup → Run workflow**။ ဒီလို ထွက်ရမယ်:
```
[OK]   Secrets
[OK]   Google Sheet
[OK]   Gemini - model = gemini-3.8-flash
[OK]   Standard Ebooks
```
`[FAIL]` ပါရင် အဲဒီစာကြောင်းကို copy လုပ်ပြီး Claude ကို ပြပါ။ (Stories tab ကို ဒီအဆင့်မှာ အလိုအလျောက် ဆောက်ပေးပါတယ်။)

---

## နေ့စဉ် အသုံးပြုပုံ

### အဆင့် A - စာအုပ်ရှာ
**Actions → PyonPyin Pipeline → Run workflow → step = `find`**
- SourceQueue ထဲ ပုံပြင်နဲ့ဆင်တဲ့ စာအုပ်တွေ ဝင်လာမယ် (ပုံပြင်မဟုတ်တာတွေ ကိုယ့်ဘာသာ ကျော်ပေးတယ်)။
- ကိုယ်ကြိုက်တဲ့ စာအုပ်ကို တိုက်ရိုက်ထည့်ချင်ရင် `data/seed_books.json` ထဲမှာ Standard Ebooks စာအုပ် URL ထည့်ပါ:
  ```json
  { "urls": ["https://standardebooks.org/ebooks/....../......"] }
  ```

### အဆင့် B - လိုင်စင်စစ် (လူကိုယ်တိုင်၊ Sheet ထဲမှာ)
စာအုပ်တစ်အုပ်ကို သုံးမယ်ဆိုရင် SourceQueue ရဲ့ အဲဒီ row မှာ ဒီ column တွေ **အားလုံး** ဖြည့်ပါ:

| Column | ဖြည့်ရမယ့်တန်ဖိုး |
|---|---|
| `license_status` | `APPROVED` |
| `rights_cleared` | `YES` |
| `rights_jurisdiction` | စစ်ခဲ့တဲ့ နိုင်ငံ ဥပမာ `US;TH;MM` |
| `license_evidence` | ဘာနဲ့ စစ်ခဲ့လဲ (စာရေးသူ ကွယ်လွန်နှစ်၊ link စသည်) |
| `permission_for_translation` | `YES` |
| `permission_for_ai_processing` | `YES` |
| `permission_for_publication` | `YES` |
| `human_reviewer` | သင့်အမည် |

တစ်ခုမပြည့်ရင် Agent က အဲဒီစာအုပ်ကို လုံးဝ မထိပါ။

> ⚠️ Standard Ebooks က "**အမေရိကန်မှာပဲ** copyright မရှိဘူး" လို့ ပြောတာပါ။ ထိုင်း/မြန်မာမှာ ကာလကျန်နေနိုင်လို့ ကိုယ်တိုင် (သို့) ဥပဒေပညာရှင်နဲ့ စစ်ရပါမယ်။ ဒါက ဥပဒေအကြံပေးမဟုတ်ပါ။
> စမ်းသပ်ဖို့ **Beautiful Stories from Shakespeare** (E. Nesbit - ၁၉၂၄ ကွယ်လွန်၊ Shakespeare ပုံပြင်များ) က လွယ်တဲ့ စာအုပ်ပါ။ ဒါပေမယ့် ကိုယ်တိုင် စစ်ပြီးမှ APPROVED လုပ်ပါ။

### အဆင့် C - AI ဇာတ်လမ်းရေး
**Pipeline → step = `write`** → **Stories** tab ထဲ `DRAFT_AI` row တွေ ဝင်လာမယ် (တစ်ကြိမ် ၃ ပုဒ်)။

### အဆင့် D - ဖတ်စစ်ပြီး ထုတ်ပြန်
Stories tab မှာ `title_my`၊ `story_my` ကို ဖတ်ပြီး လိုသလို ပြင်ပါ။ အဆင်ပြေရင် `status` ကို **`PUBLISHED`** လို့ ပြောင်းပါ (မကောင်းရင် `REJECTED`)။

### အဆင့် E - Website ပေါ်တင်
**Pipeline → step = `publish-only`**။ ပြီးရင် website လိပ်စာ:
```
https://<သင့် GitHub username>.github.io/pyonpyin-agent/
Dashboard:  .../pyonpyin-agent/dashboard.html
```
(လိပ်စာအတိအကျကို Actions ထဲက `deploy` job မှာ မြင်ရတယ်။)

**Auto run**: နေ့တိုင်း မြန်မာအချိန် ၀၇:၃၀ မှာ `find` + `write` + `publish` ကို အလိုအလျောက် run ပါတယ်။ ရပ်ချင်ရင် `.github/workflows/pipeline.yml` ထဲက `schedule:` အပိုင်း ၂ ကြောင်းကို ဖျက်ပါ။

---

## ဖိုင်တွေ ဘာလုပ်လဲ

| ဖိုင် | လုပ်ငန်း |
|---|---|
| `src/story_finder.py` | စာအုပ်ရှာပြီး SourceQueue ထဲ ထည့် |
| `src/story_writer.py` | လိုင်စင်အတည်ပြုပြီး စာအုပ်ကို မြန်မာလို ပြန်ရေး |
| `src/export_site_data.py` | PUBLISHED ဇာတ်လမ်းတွေကို website JSON ထုတ် |
| `src/check_setup.py` | Setup အကုန်စစ် |
| `prompts/story_writer.txt` | Gemini ကို ပေးတဲ့ ညွှန်ကြားချက် (ပြင်လို့ရတယ်) |
| `data/approved_sources.json` | ခွင့်ပြုထားတဲ့ source စာရင်း |
| `data/seed_books.json` | ကိုယ်တိုင်ရွေးတဲ့ စာအုပ် URL များ |
| `site/` | Website (`index.html`) နဲ့ Dashboard (`dashboard.html`) |

## ပြဿနာ ဖြစ်ရင်

- **Actions မှာ အနီရောင်** → run ကိုနှိပ် → ပျက်တဲ့ step ကိုဖွင့် → error စာကြောင်းကို Claude ကို ပြပါ။
- **`discovery_error` column** (SourceQueue) မှာ စာအုပ်တစ်အုပ်ချင်း ပြဿနာ မှတ်ထားပေးတယ်။
- **Website က အလွတ်** → Stories မှာ `PUBLISHED` ရှိလား၊ မူရင်းစာအုပ်ရဲ့ လိုင်စင် column အားလုံး ပြည့်လား စစ်ပါ (မပြည့်ရင် ထုတ်ပြန်မပေးပါ)။ Dashboard က "လိုင်စင်ကြောင့် ပိတ်ထား" အရေအတွက်ကို ပြပေးတယ်။
- **Google token သက်တမ်းကုန်** → `invalid_grant` error ပေါ်ရင် token အသစ်ထုတ်ပြီး `GOOGLE_TOKEN_JSON` ကို အစားထိုးပါ။
